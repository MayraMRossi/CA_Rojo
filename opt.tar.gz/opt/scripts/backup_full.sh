#!/bin/bash

# backup_full.sh - Script de backup
# Uso: ./backup_full.sh <origen> <destino>

# --- Función de ayuda ---
mostrar_ayuda() {
    echo "Uso: $0 <directorio_origen> <directorio_destino>"
    echo ""
    echo "Realiza un backup comprimido del directorio origen en el destino."
    echo "El archivo generado incluye la fecha en formato YYYYMMDD."
    echo ""
    echo "Opciones:"
    echo "  -help    Muestra esta ayuda"
    echo ""
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
    echo "  Genera: /backup_dir/log_bkp_20240302.tar.gz"
}

# --- Opción de ayuda ---
if [ "$1" == "-help" ]; then
    mostrar_ayuda
    exit 0
fi

# --- Validar que se pasaron los dos argumentos ---
if [ $# -ne 2 ]; then
    echo "Error: se requieren 2 argumentos (origen y destino)."
    echo "Use '$0 -help' para más información."
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# --- Validar que el origen existe ---
if [ ! -d "$ORIGEN" ]; then
    echo "Error: el directorio origen '$ORIGEN' no existe o no está disponible."
    exit 1
fi

# --- Validar que el destino existe ---
if [ ! -d "$DESTINO" ]; then
    echo "Error: el directorio destino '$DESTINO' no existe o no está disponible."
    exit 1
fi

# --- Armar el nombre del archivo ---
FECHA=$(date +%Y%m%d)
NOMBRE_BASE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

# --- Hacer el backup ---
tar -czf "${DESTINO}/${ARCHIVO}" "$ORIGEN"

# --- Confirmar resultado ---
if [ $? -eq 0 ]; then
    echo "Backup creado correctamente: ${DESTINO}/${ARCHIVO}"
else
    echo "Error: falló la creación del backup."
    exit 1
fi
