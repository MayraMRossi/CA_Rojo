history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostname
/cd /etc
cd ..
cd /etc
cd hostname
nano hostname
apt install nano
apt-get install nano
apt update
ping 8.8.8.8
cd network/
ls
vi interfaces
cd ..
ls
vi resolv.conf 
vi hostname 
reboot
vi /etc/apt/sources.list
apt update
ping -c 3 8.8.8.8
cd ..
cd /etc/resolv.conf
vi /etc/resolv.conf
ping google.com.ar
ping google.com
ping -4 -c 3 google.com
vi /etc/resolv.conf
ping google.com
cd /etc/apt/apt.conf.d/
ls
apt -o Aquire::ForceIPv4=true update
apt -o Acquire::ForceIPv4=true update
reboot
cat /etc/resolv.conf 
vi /etc/resolv.conf 
ls -l /etc/resolv.conf 
cat /etc/apt/apt.conf.d/99force-ipv4
vim /etc/apt/apt.conf.d/99force-ipv4
cat /etc/apt/apt.conf.d/99force-ipv4
apt update
vi /etc/dhcp/dhclient.conf 
dhclient -r && dhclient
cat /etc/resolv.conf 
apt update
nslookup cdn2-fastly.deb.debian.or
getent hosts cdn2-fastly.deb.debian.or
getent hosts cdn2-fastly.deb.debian.org
getent hosts google.com.
getent ahostsv4 cdn2-fastly.deb.debian.org
getent hosts deb.debian.org
vi /etc/apt/sources.list
apt update
sudo apt full-upgrade
reboot
vi /etc/apt/sources.list
apt update
apt upgrade --without-new-packages
apt upgrade --without-new-pkgs
apt full-upgrade
apt full-upgrade --fix-missing
cat /etc/resolv.conf 
apt update
apt full-upgrade
sudo reboot
cat /etc/debian_version
uname -r
sudo apt update
sudo apt install openssh-server
systemctl status ssh
apt install nano
ls -la
cd .ssh
ls -la
nano id_rsa
nano id_rsa
reboot
sudo apt install apache2 php libapache2-mod-php
sudo nano /etc/apache2/sites-available/000-default.conf
sudo nano /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
chmod 755 /root
chmod 644 /root/index.php /root/logo.png
sudo apt install php-mysql
sudo systemctl restart apache2
mariadb
sudo apt update
sudo apt install mariadb-server
mariadb
sudo mariadb ingenieria < /root/db.sql
mariadb
sudo mariadb ingenieria < /root/db.sql
sudo mariadb ingenieria -e "SHOW TABLES;"
mariadb ingenieria -e "SHOW TABLES;"
mariadb -e "DROP DATABASE ingenieria;"
sudo mariadb ingenieria < /root/db.sql
sudo mariadb < /root/db.sql
sudo mariadb ingenieria -e "SHOW TABLES;"
ip route | grep default
nano /etc/network/interfaces
nano id_rsa
cd .ssh
ls -la
nano id_rsa
rm id_rsa 
ip -a
ip a
nano /etc/ssh/sshd_config
systemctl restart ssh
ls -al
cat id_rsa.pub >> authorized_keys
ls
nano authorized_keys 
ls -la
nano /etc/ssh/sshd_config
systemctl restart ssh
nano /etc/ssh/sshd_config
systemctl restart ssh
ssh root@localhost
ls -al
cd ..
ls -al
sudo apt update
reboot
ip a
lsblk
fdisk /dev/sdc
lsblk
sudo mkfs.ext4 /dev/sdc1
sudo mkfs.ext4 /dev/sdc2
fdisk -l /dev/sdc
mkdir /www_dir /backup_dir
sudo mount /dev/sdc1 /www_dir
sudo mount /dev/sdc2 /backup_dir
lsblk
sudo cp /root/index.php /root/logo.png /www_dir/
sudo chmod 755 /www_dir
sudo chmod 644 /www_dir/index.php /www_dir/logo.png
sudo nano /etc/apache2/sites-available/000-default.conf
sudo nano /etc/apache2/sites-available/000-default.conf
sudo systemctl restart apache2
lsblk
blkid
nano /etc/fstab
sudo umount /www_dir /backup_dir
mount -a
sudo systemctl daemon-reload
lsblk
cat /proc/partitions
cat /proc/partitions > /opt/particion
cat /opt/particion
sudo reboot
